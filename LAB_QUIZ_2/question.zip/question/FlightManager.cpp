#include <iostream>
#include <string>
#include "FlightManager.h"
using namespace std;

// returns the city array index, given the city name
int FlightManager::getCityIndex(string name) {	
	int index = -1;
	for (int i=0; i<totalCities; i++)
		if (cities[i] == name) {
			index = i;
			break;
		}
	return index;	
}

// returns the city name, given the array index
string FlightManager::getCityName(int index) {
	return cities[index];	
}

